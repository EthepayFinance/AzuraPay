# AzuraPay

A futuristic wallet for the Kingdom of Azura.